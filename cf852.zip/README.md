
### How to run application:
* Select run from the Main class in IDE.
* Application created using Java 11.
* No specific parameters are needed to run program.

### Menu
A menu will appear on the startup with options that will allow the following:
* 0 will display the menu
* 1 will allow user to enter data to the console.
* 2 will allow user to upload a text file to read.
* 3 will output the users console input.
* 4 will write input to a file.
* 5 to exit program.

These options will loop until user selects 5 to exit the program
or stops the application manually from the IDE.

The file output will be saved to the root of the program directory.

