package com.drexel.exceptions;

public class FileInputException extends Exception {
    public FileInputException (String errorMessage) {
        super(errorMessage);
    }
}
