package com.drexel;

public class FileOutputException extends Exception{
    public FileOutputException(String errorMessage) {
        super(errorMessage);
    }
}
