package com.drexel;

public class InputFileName implements Strategy {

    @Override
    public String enterFileName(String fileName) {
        return fileName;
    }
}
