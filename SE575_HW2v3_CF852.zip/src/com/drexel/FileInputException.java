package com.drexel;

public class FileInputException extends Exception {
    public FileInputException (String errorMessage) {
        super(errorMessage);
    }
}
