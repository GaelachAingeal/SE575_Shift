package com.drexel;

public interface ReceiveInput {

    public void displayMessage();
}
