package com.drexel;

public interface Strategy {

    public String enterFileName(String fileName);
}
